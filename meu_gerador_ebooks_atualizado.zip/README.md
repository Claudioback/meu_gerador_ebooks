# 📚 Meu Gerador de E-Books

Transforme documentos PDF em e-books incríveis no formato **PDF** ou **EPUB** com poucos cliques!  
Feito para escritores, estudantes, professores e todos que amam livros. ✨

[![Deploy on Streamlit](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://streamlit.io/)

---

## 🚀 Como Usar

### Rodar Localmente

1. Clone o repositório:

```bash
git clone https://github.com/SEU_USUARIO/meu_gerador_ebooks.git
cd meu_gerador_ebooks
```

2. Instale as dependências:

```bash
pip install -r requirements.txt
```

3. Rode o aplicativo:

```bash
streamlit run app.py
```

---

### Rodar com Docker (opcional)

```bash
docker build -t gerador-ebooks .
docker run -p 8501:8501 gerador-ebooks
```

---

## ✨ Funcionalidades

- Upload de documentos PDF 📄
- Upload de capa personalizada 🖼️
- Escolha do tamanho da página (A5 ou Carta) 📏
- Configurações de margens, espaçamento e fonte 🔤
- Geração em PDF ou EPUB 📚
- Download instantâneo 📥
- Deploy automático no Streamlit Cloud ☁️

---

## 🛠️ Tecnologias

- [Streamlit](https://streamlit.io/)
- [PyMuPDF](https://pymupdf.readthedocs.io/en/latest/)
- [ReportLab](https://www.reportlab.com/)
- [Pillow](https://python-pillow.org/)
- [EbookLib](https://github.com/aerkalov/ebooklib)

---

## ❤️ Contribua

Quer sugerir melhorias ou reportar bugs?  
Sinta-se à vontade para abrir uma **issue** ou fazer um **pull request**!

---

## 🧙‍♂️ Autor

Desenvolvido com 💙 por [Seu Nome].

---

> "A melhor maneira de prever o futuro é criá-lo." – Peter Drucker